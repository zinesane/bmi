const heightInput = document.getElementById('height');
const weightInput = document.getElementById('weight');
const calculateButton = document.getElementById('calculate');
const resultDiv = document.getElementById('result');

calculateButton.addEventListener('click', () => {
  const height = parseFloat(heightInput.value);
  const weight = parseFloat(weightInput.value);

  if (isNaN(height) || isNaN(weight)) {
    resultDiv.textContent = 'Please enter valid height and weight.';
    return;
  }

  const bmi = weight / (height / 100) ** 2;

  const bmiInterpretation = interpretBMI(bmi);

  resultDiv.innerHTML = `
    <p>Your BMI is: ${bmi.toFixed(2)}</p>
    <p>${bmiInterpretation}</p>
  `;
});

function interpretBMI(bmi) {
  if (bmi < 18.5) {
    return 'Jarred';
  } else if (bmi < 25) {
    return 'Arpon';
  } else if (bmi < 30) {
    return 'Ja-ke';
  } else {
    return 'Lemmor';
  }
}